let setup = () => {

    let pElement = document.getElementById('txtOutput');
    pElement.innerHTML = "Welkom!";
}
window.addEventListener("load", setup);

