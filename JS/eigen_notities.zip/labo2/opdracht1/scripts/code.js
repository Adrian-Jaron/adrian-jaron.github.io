window.alert("Mededeling");

window.confirm("Weet u het zeker?");

window.prompt("Wat is uw naam?", "onbekend");

let confirmResult = confirm("Ben je het zeker?")
console.log(confirmResult);

let promptResult = prompt("Typ uw naam in");
console.log(promptResult);