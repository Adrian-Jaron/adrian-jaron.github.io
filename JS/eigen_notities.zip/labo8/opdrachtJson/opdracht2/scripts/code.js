let tekst = '{"firstName":"John","lastName":"Doe","age":"2000-01-31T23:00:00.000Z","eyeColor":"blue"}';
let student2 = JSON.parse(tekst);
console.log(student2);