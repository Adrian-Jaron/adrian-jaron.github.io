let paragraaf = document.querySelectorAll('p')[0];

const setup = () => {
        paragraaf.textContent = 'good job!';

}

window.addEventListener("load", setup);
