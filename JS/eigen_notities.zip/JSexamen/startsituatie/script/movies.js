// dit bestand mag je niet aanpassen
let movies =
[
	{
		id : 1,
		title: "Transformers: Age of Extinction (2014)",
		imageUrl : "images/transformers.jpg",
		description: "A mechanic and his family join the Autobots as they are targeted by a bounty hunter from another world."
	},
	{
		id: 2,
		title: "Dawn of the Planet of the Apes (2014)",
		imageUrl : "images/planetoftheapes.jpg",
		description: "In the wake of a disaster that changed the world, the growing and genetically evolving apes find themselves at a critical point with the human race."
	},
	{
		id: 3,
		title: "Guardians of the Galaxy (2014)",
		imageUrl : "images/guardians.jpg",
		description: "Light years from Earth, 26 years after being abducted, Peter Quill finds himself the prime target of a manhunt after discovering an orb wanted by Ronan the Accuser."
	},
	{
		id: 4,
		title: "How to Train Your Dragon 2 (2014)",
		imageUrl : "images/dragon.jpg",
		description: "When Hiccup and Toothless discover an ice cave that is home to hundreds of new wild dragons and the mysterious Dragon Rider, the two friends find themselves at the center of a battle to protect the peace."
	},
	{
		id: 5,
		title: "Lucy (2014)",
		imageUrl : "images/lucy.jpg",
		description: "A woman, accidentally caught in a dark deal, turns the tables on her captors and transforms into a merciless warrior evolved beyond human logic."
	},
	{
		id: 6,
		title: "Planes: Fire & Rescue (2014)",
		imageUrl: "images/planes.jpg",
		description: "When Dusty learns that his engine is damaged and he may never race again, he joins a forest fire and rescue unit to be trained as a firefighter."
	},
	{
		id: 7,
		title: "Blue Ruin (2013)",
		imageUrl: "images/blueruin.jpg",
		description: "A mysterious outsider's quiet life is turned upside down when he returns to his childhood home to carry out an act of vengeance. Proving himself an amateur assassin, he winds up in a brutal fight to protect his estranged family."
	},
	{
		id: 8,
		title: "Into the Storm (2014)",
		imageUrl: "images/intothestorm.jpg",
		description: "Storm trackers, thrill-seekers, and everyday townspeople document an unprecedented onslaught of tornadoes touching down in the town of Silverton."
	},
	{
		id: 9,
		title: "Edge of Tomorrow (2014)",
		imageUrl: "images/edgeoftomorrow.jpg",
		description: "An officer finds himself caught in a time loop in a war with an alien race. His skills increase as he faces the same brutal combat scenarios, and his union with a Special Forces warrior gets him closer and closer to defeating the enemy."
	},
	{
		id: 10,
		title: "Maleficent (2014)",
		imageUrl: "images/maleficent.jpg",
		description: "A vengeful fairy is driven to curse an infant princess, only to discover that the child may be the one person who can restore peace to their troubled land."
	}
];
